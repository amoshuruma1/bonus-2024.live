

if (typeof window.orientation == 'undefined' && screen.width >= 1000){
        window.location.href = 'https://sape.ngumaz.com/api/direct/450299?s1=%subid1%&kw';
}
